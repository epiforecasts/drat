library(testthat)
library(EpiNow2)

test_check("EpiNow2")
