library(testthat)
library(covidregionaldata)
source("testthat/custom_tests/mock_data.R")

test_check("covidregionaldata")
