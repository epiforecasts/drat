library(testthat)
library(scoringutils)

test_check("scoringutils")
