# EpiNow2 0.1.0


* Rebased package from [EpiNow](https://epiforecasts.io/EpiNow/)
