# covid19.nhs.data 0.1.0

* Initial package version with basic functionality.
