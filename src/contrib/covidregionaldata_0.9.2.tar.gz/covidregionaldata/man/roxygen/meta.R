list(
  rd_family_title = list(
    aggregations = "Aggregated data sources",
    subnational = "Subnational data sources",
    national = "National data sources",
    interface = "Data interface functions",
    compulsory_processing = "Compulsory processing functions",
    optional_processing = "Optional processing function",
    processing = "Functions used in the processing pipeline",
    tests = "Functions used for testing data is cleaned and processed correctly"
  )
)
