# RtD3 0.0.1

* Added a `NEWS.md` file to track changes to the package.
* Added converter functions for `EpiNow2` estimates.
* Added `summaryWidget`
* Added introductory vignettes (as external documentation).

