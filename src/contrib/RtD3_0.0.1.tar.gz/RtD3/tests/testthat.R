library(testthat)
library(RtD3)

test_check("RtD3")
