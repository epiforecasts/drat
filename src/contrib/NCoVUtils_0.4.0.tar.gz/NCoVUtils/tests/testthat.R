library(testthat)
library(NCoVUtils)

test_check("NCoVUtils")
