# EpiSoon 0.3.0

* Reviewed and updated all tooling and examples
* Added documentation 
* Bugs squashed.

# EpiSoon 0.2.0

* Added a `NEWS.md` file to track changes to the package.
* Added dev support for multiple samples to `evaluate_model` and all higher order functions. Note that this user is expected to manage this themselves for lower level functions. 
* Renamed models to reflect forecasting and not fitting.
* Updated all docs to reflect changes.
* Added case prediction and scoring framework
