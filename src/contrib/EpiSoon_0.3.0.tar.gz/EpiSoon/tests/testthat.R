library("testthat")
library("EpiSoon")

test_check("EpiSoon")
