library(testthat)
library(covidregionaldata)

test_check("covidregionaldata")
