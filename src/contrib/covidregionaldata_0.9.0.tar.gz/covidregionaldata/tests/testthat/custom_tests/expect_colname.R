expect_colname <- function(expected_colname, colnames) {
  expect_true(expected_colname %in% colnames)
}
